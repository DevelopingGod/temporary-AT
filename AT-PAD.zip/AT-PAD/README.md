# 🤖 AT Reviews — Automated Review Scraping Suite

> **Power Automate Desktop bots for GetYourGuide, Viator, Klook, and Civitatis.**
> Automatically collects, normalises, and routes customer reviews into a shared Excel workbook — categorised by platform, month, and region.

---

## 📋 Table of Contents

1. [Overview](#-overview)
2. [Prerequisites](#-prerequisites)
3. [File Structure](#-file-structure)
4. [Installation](#-installation)
5. [First-Time Setup — Requestly (GYG Only)](#-first-time-setup--requestly-gyg-only)
6. [Configuration](#️-configuration)
7. [Running the Bots](#-running-the-bots)
   - [GetYourGuide](#1️⃣-getyourguide)
   - [Viator](#2️⃣-viator)
   - [Klook](#3️⃣-klook)
   - [Civitatis](#4️⃣-civitatis)
8. [Excel Output Structure](#-excel-output-structure)
9. [Guide Name Extraction](#-guide-name-extraction-textjoin-formula)
10. [Quick Troubleshooting](#-quick-troubleshooting)

---

## 🌐 Overview

This suite consists of **four Power Automate Desktop (PAD) flows**, each targeting a different OTA (Online Travel Agency) review portal:

| Bot | Source | Extraction Method | Scale |
|-----|--------|-------------------|-------|
| **GetYourGuide** | Supplier Portal API | GraphQL REST API via bearer token interception | 1–5 ★ |
| **Viator** | Supplier Portal | Hidden JSON state (`__PRELOADED_STATE__`) + DOM fallback | 1–5 ★ |
| **Klook** | Merchant Portal | JavaScript DOM scraping (Ant Design table rows) | 1–5 ★ |
| **Civitatis** | Downloaded `.xls` report | Direct Excel file reading | 1–10 📊 |

All four bots share the same **ETL pipeline**: they normalise ratings to a 1–10 scale, classify each review as **Promotor / Pasivo / Detractor** (NPS), map destination names to Spanish, standardise tour titles, and write results to the correct monthly/regional sheet in a single `.xlsm` workbook.

---

## ✅ Prerequisites

Before running any bot, ensure the following are installed and accessible:

| Requirement | Details |
|---|---|
| **Microsoft Edge** | Default browser — all bots launch Edge sessions |
| **Power Automate Desktop** | v2.40 or later recommended |
| **Microsoft Excel** | Must support `.xlsm` macro-enabled workbooks |
| **Requestly** (browser extension) | **GYG only** — required to intercept the bearer token |
| **Supplier portal accounts** | Active credentials for each platform you intend to scrape |
| **Output workbook** | `C:\AT-Reviews\Viator_Reviews_2026.xlsm` must exist and be pre-configured with the correct sheets |
| **Civitatis report** | `C:\AT-Reviews\listado.xls` — downloaded from the Civitatis panel before running |

> ⚠️ **Important:** The output Excel file path is hardcoded to `C:\AT-Reviews\Viator_Reviews_2026.xlsm`. If your file is in a different location, update the path before running (see [Configuration](#️-configuration)).

---

## 📁 File Structure

```
D:\AT-PAD\
├── GYG-Power-Automate-FINAL.txt        ← GetYourGuide PAD flow
├── Viator-Power-Automate-FINAL.txt     ← Viator PAD flow
├── Klook-Power-Automate.txt            ← Klook PAD flow
├── Civitatis-Power-Automate.txt        ← Civitatis PAD flow
├── Requestly-Script.txt                ← JS fetch interceptor for GYG
└── README.md                           ← This file

C:\AT-Reviews\
├── Viator_Reviews_2026.xlsm            ← Shared output workbook
└── listado.xls                         ← Civitatis source report (downloaded manually)
```

---

## 📦 Installation

There are two methods to import a PAD flow. **Method A is recommended** for clean environments.

---

### Method A — Import via Cloud Solution `.zip` ⭐ Recommended

1. Open **Power Automate Desktop**.
2. Click **"..."** (ellipsis) next to your environment name → **Solutions**.
3. Click **Import** → **Browse** → select the `.zip` solution file.
4. Follow the import wizard. The flow will appear in your **My flows** list.

---

### Method B — Text Paste (Manual Import from `.txt`)

> Use this method when you only have the `.txt` source files in this folder.

#### ⚠️ The "Notepad Cleanse" — Do This First!

Copying text directly from a browser or rich-text editor embeds invisible HTML formatting characters that **will cause PAD to reject the paste silently**. Always cleanse the clipboard first:

1. Open the `.txt` file in **File Explorer** by double-clicking it.
2. Press **Ctrl+A** to select all, then **Ctrl+C** to copy.
3. Open **Notepad** (Windows built-in, not Notepad++).
4. Press **Ctrl+V** to paste into Notepad.
5. Press **Ctrl+A** again to select all text in Notepad.
6. Press **Ctrl+C** — the clipboard now contains clean, plain text.

#### Paste into PAD

7. Open **Power Automate Desktop**.
8. Click **"+ New flow"** → give it a name (e.g., `AT - GetYourGuide`).
9. Inside the blank flow editor, click anywhere in the **action workspace**.
10. Press **Ctrl+V** to paste.
11. The flow actions should appear immediately. If nothing happens, repeat the Notepad Cleanse.

> 💡 **Tip:** Create a separate flow for each bot. Do not paste multiple bots into the same flow.

---

## 🔑 First-Time Setup — Requestly (GYG Only)

The GetYourGuide bot requires a **Requestly** browser extension rule to capture the API bearer token. This is a one-time setup.

### Step 1 — Install Requestly

1. Install the [Requestly extension](https://requestly.com/) for **Microsoft Edge** from the Edge Add-ons store.
2. Pin it to your toolbar for easy access.

### Step 2 — Create the Interceptor Rule

1. Click the Requestly icon in Edge → **Open App**.
2. Click **"+ New Rule"** → select **"Modify API Response"** or use **"Custom Script (UserScript)"**.
3. Select **"Insert Script"** rule type.
4. Set the rule to match: `*supplier.getyourguide.com*`
5. Set the script type to **"Before Page Load"**.
6. Open `Requestly-Script.txt` from this folder, copy the entire contents, and paste it into the script body field.
7. **Save and enable** the rule.

### Step 3 — Verify it Works

1. Navigate to `https://supplier.getyourguide.com/reviews` in Edge.
2. Open the browser **Developer Tools** (F12) → **Console** tab.
3. You should see: `✅ Fetch interceptor installed`
4. After clicking any filter on the reviews page, you should see: `🔐 Token captured: eyJ...`

> ✅ Once this message appears, the Requestly rule is working correctly. You do not need to repeat this setup unless you reinstall Edge or clear your extension data.

---

## ⚙️ Configuration

Before running any bot for the first time, verify or update these variables directly inside the PAD flow editor.

### Common to All Bots

| Variable | Location in Flow | Default | Description |
|---|---|---|---|
| `DaysBack` | Line 1 (first `SET` action) | GYG: `4`, Viator: `1`, Klook/Civitatis: `60` | How many days back to scrape reviews |
| Excel path | `Excel.LaunchExcel` action | `C:\AT-Reviews\Viator_Reviews_2026.xlsm` | Full path to the output workbook |

### Civitatis Only

| Variable | Location | Default | Description |
|---|---|---|---|
| `listado.xls` path | Second `Excel.LaunchExcel` action | `C:\AT-Reviews\listado.xls` | Path to the Civitatis source export file |

### How to Change a Variable in PAD

1. Open the flow in **PAD editor**.
2. Double-click the first **`Set variable`** action.
3. Change the value in the **"To"** field (e.g., change `4` to `7`).
4. Click **Save**.

> ⚠️ **For DaysBack:** Be conservative. Setting this too high on Viator or GYG may result in very large scraping sessions. The recommended weekly value is `7`; for catchup runs use `30` or `60`.

---

## ▶️ Running the Bots

---

### 1️⃣ GetYourGuide

**File:** `GYG-Power-Automate-FINAL.txt`

**Before you start:** Confirm the Requestly interceptor rule is enabled in Edge.

**Steps:**

1. Run the flow in PAD.
2. 🌐 Edge opens the GYG Supplier login page automatically.
3. **[MANUAL ACTION]** Log in with your email and password.
4. **[MANUAL ACTION]** Open **Google Authenticator**, enter the 6-digit 2FA code.
5. **[MANUAL ACTION]** Navigate to the **Reviews** page and wait until reviews are fully visible on screen.
6. Click **OK** on the PAD dialog _"GYG Login Required"_.
7. A second dialog asks: **"Which Account?"** — type your region (e.g., `UK`, `EUR`, `USA`, `MEX`, or `JP`) and click **OK**.
8. A third dialog appears: **"Capture Token"** — do **NOT** click OK yet.
9. **[MANUAL ACTION]** On the GYG Reviews page, click **any filter** (e.g., change the sort order, change the date range, or click "Next page"). Wait for the reviews to reload.
10. Now click **OK** on the PAD dialog.
11. The bot will display the captured token for confirmation — click **OK** to proceed.
12. The flow runs automatically, fetching reviews via the API in batches of 50.
13. ✅ A final dialog shows the total reviews written. Click **OK**.

> ⚠️ **Critical:** Do **not** click OK on the "Capture Token" dialog until you have already clicked a filter and seen the page reload. Clicking too early results in a `Token not found` error.

---

### 2️⃣ Viator

**File:** `Viator-Power-Automate-FINAL.txt`

**Steps:**

1. Run the flow in PAD.
2. A dialog asks: **"Which supplier account are you scraping?"** — select the correct account from the list and click **OK**.
3. 🌐 Edge opens the Viator Supplier login page.
4. **[MANUAL ACTION]** Log in with your Viator credentials. Complete any CAPTCHA if it appears.
5. **[MANUAL ACTION]** Navigate to the **Reviews** page. Wait for the reviews table to **fully load** — all review cards must be visible.
6. Click **OK** on the PAD dialog _"Viator Login Required"_.
7. The bot extracts reviews from the hidden page state, then paginates through all available pages automatically.
8. A confirmation dialog shows the total collected — click **OK** to begin writing to Excel.
9. ✅ The workbook is saved automatically.

> ⚠️ **Critical:** Clicking OK before the Reviews page is fully loaded will cause the JavaScript extraction to fail with an error. If this happens, close the flow and restart.

---

### 3️⃣ Klook

**File:** `Klook-Power-Automate.txt`

**Steps:**

1. Run the flow in PAD.
2. A dialog asks: **"Which supplier account are you scraping?"** — select the correct account and click **OK**.
3. 🌐 Edge opens `https://merchant.klook.com/reviews`.
4. **[MANUAL ACTION]** Log in to the Klook Merchant portal if not already logged in.
5. **[MANUAL ACTION]** Navigate to the **Reviews** page. Wait until the review table rows are **fully rendered** on screen.
6. Click **OK** on the PAD dialog _"Klook Login Required"_.
7. The bot scrapes the visible table page by page, clicking "Next Page" automatically.
8. ✅ A final dialog shows the total reviews written. Click **OK**.

> ⚠️ **Critical:** The Klook table uses Ant Design's virtual rendering. If you click OK before rows are visible, 0 reviews will be extracted. Always confirm the table is populated before clicking OK.

> 💡 **Note:** Klook does not expose reviewer usernames — all Klook reviews are written as `Anonymous`.

---

### 4️⃣ Civitatis

**File:** `Civitatis-Power-Automate.txt`

**Before you start:** Download the `listado.xls` report from the Civitatis supplier panel and save it to `C:\AT-Reviews\listado.xls`.

**Steps:**

1. Download the **Civitatis reviews report** (`listado.xls`) from your Civitatis supplier panel.
2. Save it to: `C:\AT-Reviews\listado.xls` (overwrite the previous file).
3. Run the flow in PAD.
4. A dialog asks: **"Which region is this listado.xls for?"** — select `LATAM`, `EUR_NY`, or `JAP` and click **OK**.
5. The bot opens the `.xls` file, skips the header rows, and processes all reviews within the configured `DaysBack` date range.
6. ✅ A final dialog shows the total reviews written. Click **OK**.

> 💡 **Note:** Unlike the other bots, Civitatis does **not** open a browser. It reads entirely from the downloaded file. Civitatis uses a 1–10 rating scale natively; no conversion is needed for `Calificación`.

---

## 📊 Excel Output Structure

All bots write to the same workbook: **`C:\AT-Reviews\Viator_Reviews_2026.xlsm`**

### Sheet Naming Convention

Sheets are named `{MONTH}_{REGION}`:

| Component | Values |
|---|---|
| Month | `ENE`, `FEB`, `MAR`, `ABR`, `MAY`, `JUN`, `JUL`, `AGO`, `SEP`, `OCT`, `NOV`, `DIC` |
| Region | `EUR_NY`, `LATAM`, `JAP` |

**Examples:** `ABR_EUR_NY` · `ENE_LATAM` · `DIC_JAP`

The region is determined automatically by the **Destino** (destination) of each review:

| Region Sheet | Destinations |
|---|---|
| `EUR_NY` | Londres, Ámsterdam, Barcelona, Madrid, Roma, París, Milán, Nueva York, Granada, Sevilla, Florencia, Venecia, Toledo y Segovia |
| `LATAM` | Cancún, Ciudad de México |
| `JAP` | Tokyo, Kyoto, Osaka |

### Column Mapping

Each row written to Excel follows this structure:

| Column | Field | Notes |
|---|---|---|
| **A** | Confirmado | Always `SI` |
| **B** | Agencia | Platform name (`GetYourGuide`, `Viator`, `TripAdvisor`, `Klook`, `Civitatis`) |
| **C** | Reviewer Name | `Anonymous` for Klook and Civitatis |
| **D** | Review / Booking ID | Platform-specific identifier |
| **E** | Destino | Standardised Spanish destination name |
| **F** | Tipo de Servicio | `Tour` or `Ticket` |
| **G** | Tour Title | Standardised Spanish tour name |
| **H** | Review Date | `YYYY-MM-DD` |
| **I** | Activity Date | Date of tour participation (GYG & Klook only) |
| **J** | Calificación | Rating on a 1–10 scale |
| **K** | Rating | Raw platform rating (1–5 for GYG/Viator/Klook; 1–10 for Civitatis ÷ 2) |
| **L** | Área Correspondiente | Always `Tour` |
| **Q** | Comentario | Full review text |
| **R** | NPS | `Promotor`, `Pasivo`, or `Detractor` |

### NPS Classification

| Platform | Promotor | Pasivo | Detractor |
|---|---|---|---|
| GYG / Viator / Klook | Rating = **5** | Rating = **4** | Rating ≤ **3** |
| Civitatis | Nota ≥ **9** | Nota **7–8** | Nota ≤ **6** |

### Score Normalisation

| Platform | Raw Scale | Calificación Formula |
|---|---|---|
| GYG / Viator / Klook | 1–5 stars | `Calificación = Rating × 2` |
| Civitatis | 1–10 points | `Calificación = Nota` (no conversion needed) |

---

## 👤 Guide Name Extraction (TEXTJOIN Formula)

The output workbook uses an Excel array formula to automatically detect which company guide is mentioned in a review comment.

### How It Works

In the `Guía` column of your output sheet, enter this formula:

```excel
=TEXTJOIN(", ", TRUE, FILTER(GuidesList!A:A, ISNUMBER(SEARCH(" " & GuidesList!A:A & " ", " " & [@Comentario] & " "))))
```

This formula:
- Searches the review text in `[@Comentario]` for any guide name from the `GuidesList` sheet.
- Returns all matching guide names, comma-separated.
- Is case-insensitive (uses `SEARCH` not `FIND`).
- Pads the search with spaces to prevent partial name matches.

### Setting Up the GuidesList Sheet

1. In your `.xlsm` workbook, navigate to (or create) a sheet named **`GuidesList`**.
2. In **Column A**, list one guide name per row, starting from row 1:

```
Carlos
Maria
Pedro
Ana Rodriguez
...
```

3. **Important:** Use the guide's **full name as it appears in reviews**. For common first names, add the last name to avoid false matches.

### Updating the Guide List

- To **add** a new guide: simply add their name to the next empty row in `GuidesList!A`.
- To **remove** a guide: delete their row.
- The formula recalculates automatically — no changes to the formula itself are needed.

> 💡 **Tip:** If a guide has a very common first name (e.g., "Carlos"), always use their full name in GuidesList to avoid false positives in unrelated reviews.

---

## 🛠️ Quick Troubleshooting

| Symptom | Likely Cause | Fix |
|---|---|---|
| **PAD refuses to paste `.txt` code** | Clipboard contains invisible HTML formatting | Use the [Notepad Cleanse](#️-the-notepad-cleanse--do-this-first) method |
| **"Token not found" (GYG)** | Clicked OK before triggering a filter/page reload | Restart flow; click a filter first, wait for reload, then click OK |
| **`Unexpected character 'E'` parse error (Viator/Klook)** | JS returned `"ERROR: No script found"` — page not fully loaded | Restart flow; wait for full page load before clicking OK |
| **0 reviews extracted (Klook)** | Table rows not yet visible, or date comparison failed | Confirm table is populated; check `DaysBack` variable uses `%` signs not literal text |
| **"Datetime must be Datetime" (Civitatis)** | Script attempted to parse a header or blank row | Verify `listado.xls` has 4 header rows; do not manually modify the file structure |
| **Wrong sheet / no sheet found** | Destination not in the mapping, or sheet doesn't exist | Add destination to mapping in the flow; create the missing sheet in the workbook |
| **Reviews written to wrong month** | Running the bot in a different month than expected | Check `DaysBack` — reviews are routed to the sheet for the **current calendar month** |

---

*Suite maintained by the AT Operations team. For developer documentation, architecture details, and error-handling deep-dives, see `DEVELOPER_GUIDE.docx`.*
