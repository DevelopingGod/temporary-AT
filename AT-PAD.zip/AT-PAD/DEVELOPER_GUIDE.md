# 🛠️ AT Reviews — Developer & Maintenance Guide

> **Technical Reference for the Power Automate Desktop Scraping Suite**
> For operator-facing run instructions, see [`README.md`](README.md).

---

## 📋 Table of Contents

1. [Architecture Overview](#1️⃣-architecture-overview)
2. [GetYourGuide Bot — Technical Deep Dive](#2️⃣-getyourguide-bot--technical-deep-dive)
3. [Viator Bot — Technical Deep Dive](#3️⃣-viator-bot--technical-deep-dive)
4. [Klook Bot — Technical Deep Dive](#4️⃣-klook-bot--technical-deep-dive)
5. [Civitatis Bot — Technical Deep Dive](#5️⃣-civitatis-bot--technical-deep-dive)
6. [Core ETL Logic (Common to All Bots)](#6️⃣-core-etl-logic-common-to-all-bots)
7. [Modifying the Logic](#7️⃣-modifying-the-logic)
8. [Common Errors & Fixes](#8️⃣-common-errors--fixes)
9. [Guide Name Extraction — TEXTJOIN Formula](#9️⃣-guide-name-extraction--textjoin-formula)
10. [Adding a New Platform](#-adding-a-new-platform)
11. [Appendix A — PAD Action Quick Reference](#appendix-a--pad-action-quick-reference)
12. [Appendix B — Variable Naming Conventions](#appendix-b--variable-naming-conventions)

---

## 1️⃣ Architecture Overview

### 1.1 Design Philosophy

This suite follows a **hybrid automation model** where Power Automate Desktop (PAD) acts as the **orchestrator** and JavaScript handles all **web extraction logic**. This separation is intentional:

| Layer | Responsibility |
|---|---|
| **PAD** | Browser lifecycle, user prompts, variable management, Excel I/O, pagination loops, error branching |
| **JavaScript** | DOM querying, JSON parsing, date filtering, NPS calculation, destination mapping, data serialisation |

This design is robust because JavaScript runs inside the browser's own engine — it has full access to the page's rendered DOM, intercepted network state, and in-memory JavaScript objects. PAD's built-in web scraping actions, by contrast, rely on UI element selectors that break whenever a platform redesigns its frontend.

### 1.2 System Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                        INPUT LAYER                          │
│   OTA Supplier Portals (GYG, Viator, Klook)                │
│   Downloaded File (Civitatis listado.xls)                  │
└──────────────────────┬──────────────────────────────────────┘
                       │
┌──────────────────────▼──────────────────────────────────────┐
│                   INTERCEPTION LAYER                        │
│   Requestly (GYG only) — Patches window.fetch to           │
│   capture Bearer token from outgoing API requests          │
└──────────────────────┬──────────────────────────────────────┘
                       │
┌──────────────────────▼──────────────────────────────────────┐
│               ORCHESTRATION LAYER (PAD)                     │
│   Controls flow • User prompts • Loops • Excel writes      │
│   ┌─────────────────────────────────────────────────────┐  │
│   │          EXTRACTION LAYER (JavaScript)              │  │
│   │  DOM scraping • JSON parsing • Date filtering       │  │
│   │  NPS calc • Destino mapping • Title standardisation │  │
│   └─────────────────────────────────────────────────────┘  │
└──────────────────────┬──────────────────────────────────────┘
                       │
┌──────────────────────▼──────────────────────────────────────┐
│                      OUTPUT LAYER                           │
│   Viator_Reviews_2026.xlsm                                 │
│   Sheets: {MONTH}_{REGION}  e.g. ABR_EUR_NY, ENE_LATAM    │
└─────────────────────────────────────────────────────────────┘
```

### 1.3 Technology Stack

| Technology | Notes | Purpose |
|---|---|---|
| Power Automate Desktop | v2.40+ | Orchestration, Excel I/O, browser automation |
| Microsoft Edge | Chromium-based | Browser host for all web bots |
| JavaScript | **ES5 strictly** — no ES6+ | DOM/JSON extraction inside browser |
| Excel `.xlsm` | Macro-enabled workbook | Output storage with TEXTJOIN formula |
| Requestly | Browser extension | Fetch API interception for GYG token |

> ⚠️ **Critical — ES5 Only:** All JavaScript inside PAD flows must be written in **ES5**. PAD's JavaScript executor does not support ES6+ syntax. This means:
> - No arrow functions (`=>`) — use `function()`
> - No `const` or `let` — use `var`
> - No template literals (`` ` ``) — use string concatenation
> - No spread operators, destructuring, or `Promise`
> - Array/NodeList access: use `.item(index)` not `[index]` (see Section 4.2)

### 1.4 Excel Output Schema

All four bots write to `C:\AT-Reviews\Viator_Reviews_2026.xlsm` using this column schema:

| Column | Field Name | Type | Source |
|---|---|---|---|
| **A** | Confirmado | Text — always `SI` | Hardcoded |
| **B** | Agencia | Text | Platform name |
| **C** | Reviewer Name | Text | Platform / `Anonymous` |
| **D** | Review ID / Booking Ref | Text | Platform identifier |
| **E** | Destino | Text | Derived from tour title |
| **F** | Tipo de Servicio | Text | `Tour` or `Ticket` |
| **G** | Tour Title | Text | Standardised Spanish name |
| **H** | Review Date | `YYYY-MM-DD` | Platform |
| **I** | Activity/Participation Date | `YYYY-MM-DD` | GYG & Klook only |
| **J** | Calificación | Number 1–10 | Calculated |
| **K** | Raw Rating | Number | Platform raw value |
| **L** | Área Correspondiente | Text — always `Tour` | Hardcoded |
| **M–P** | _(reserved)_ | — | TEXTJOIN guide formula + manual annotations |
| **Q** | Comentario | Text | Full review text |
| **R** | NPS | Text | `Promotor` / `Pasivo` / `Detractor` |

### 1.5 Sheet Routing Logic

Sheets are named `{MONTH}_{REGION}`, where month is the current calendar month at execution time and region is derived from the review's **Destino**:

| Region Code | Destinations Routed Here |
|---|---|
| `EUR_NY` | Londres, Ámsterdam, Barcelona, Madrid, Roma, París, Milán, Nueva York, Granada, Sevilla, Florencia, Venecia, Toledo y Segovia |
| `LATAM` | Cancún, Ciudad de México |
| `JAP` | Tokyo, Kyoto, Osaka |

**Sheet examples:** `ABR_EUR_NY` · `ENE_LATAM` · `DIC_JAP`

---

## 2️⃣ GetYourGuide Bot — Technical Deep Dive

**File:** `GYG-Power-Automate-FINAL.txt`

### 2.1 Why API Interception Instead of DOM Scraping

The GYG supplier portal renders reviews via React with dynamic IDs and class names that change on every deployment. A UI-based scraper targeting CSS selectors would break with every frontend update.

Instead, this bot targets **GYG's own internal GraphQL API:**

```
POST https://supplier.getyourguide.com/graphql
```

This API is stable across frontend deployments. However, it requires a valid **bearer token** (JWT) issued after login + 2FA, which the browser uses to authenticate every API request.

**Why this is better than DOM scraping:**
- The API returns clean, structured JSON — no HTML parsing needed
- Pagination is controlled via `offset` parameter — no fragile "click Next" UI logic
- The response schema is far more stable than CSS class names

### 2.2 The Requestly Token Interceptor

`Requestly-Script.txt` contains a JavaScript snippet injected into the page **before page load** via Requestly. It monkey-patches `window.fetch` to observe every outgoing network request:

```javascript
// Simplified — see Requestly-Script.txt for full implementation
window.__authStore = { token: null };

const origFetch = window.fetch;
window.fetch = function (...args) {
    // Inspect each fetch call's Authorization header
    var auth = /* extract Authorization header from args */;
    if (auth && !window.__authStore.token) {
        // Store ONLY the first token captured (prevents refresh token overwrite)
        window.__authStore.token = auth.replace(/^Bearer\s+/i, '');
    }
    return origFetch.apply(this, args); // Pass through — non-destructive
};

window.getAuthToken = function () {
    return window.__authStore.token;
};
```

**Key design decisions:**

| Decision | Reason |
|---|---|
| `if(window.__authStore.token) return;` | Captures only the FIRST token — prevents refresh tokens from overwriting the primary session token |
| Installed **before page load** via Requestly | Ensures the interceptor wraps `fetch` before any GYG JavaScript runs |
| Completely non-destructive | Does not block or modify requests — only observes headers |

### 2.3 How PAD Reads the Token

After the user clicks a filter on the reviews page (triggering a GraphQL fetch that the interceptor captures), PAD reads the stored token from the window object:

```javascript
// PAD ExecuteJavascript block
function ExecuteScript() {
    var authToken = window.__authStore.token || "";
    authToken = "Bearer " + authToken;
    return authToken || "";
}
```

Result is stored in `TempToken` → copied to `AuthToken`. If `AuthToken` is still empty, PAD shows a retry dialog.

### 2.4 The GraphQL Pagination Loop

The bot runs up to **100 iterations** (offset 0 → 4950, 50 results per page):

```
LOOP LoopIndex FROM 0 TO 99
    POST to /graphql with offset = Offset (starts at 0)
    
    IF StatusCode ≠ 200 → show "Token expired" error → EXIT
    
    Parse JSON → iterate reviews:
        IF review.createdAt < CutoffDate → SET BatchHitCutoff = True → EXIT LOOP
        ELSE → extract fields → write to Excel
    
    IF BatchSize < 50 → last page reached → EXIT LOOP
    IF BatchHitCutoff = True → EXIT LOOP
    SET Offset = Offset + 50
END
```

### 2.5 GYG-Specific Field Mappings

| GraphQL Path | PAD Variable | Notes |
|---|---|---|
| `bookingReference` | `ReviewId` | The booking reference, not the review ID |
| `rating` | `RatingValue` | 1–5 scale |
| `rating × 2` | `Calificacion` | Normalised to 1–10 |
| `comment` | `CommentText` | Full review text |
| `activityStartDate` | `ActivityDate` | Date of the tour (written to col I) |
| `createdAt` | `ReviewDateTime` | Used for cutoff comparison |
| `activity.sourceText.title` | `TourTitle` | Used for Destino detection and title standardisation |
| `author.fullName` | `ReviewerName` | `"GetYourGuide traveler"` → remapped to `"Anonymous"` |
| `ratings[ratingType=rating_guide].ratingValue` | `GuideRating` | Per-guide sub-rating — currently not written to a column; available for future use |

### 2.6 Supplier ID Auto-Detection

The bot reads the active supplier from the browser session cookie rather than hardcoding it:

```javascript
function ExecuteScript() {
    var m = document.cookie.match(/supplier_id=([^;]+)/);
    return m ? m[1].trim() : "45999";
}
```

The fallback `45999` is the default supplier. This allows the bot to work across multiple GYG accounts without code changes.

---

## 3️⃣ Viator Bot — Technical Deep Dive

**File:** `Viator-Power-Automate-FINAL.txt`

### 3.1 Why `__PRELOADED_STATE__` Instead of DOM Scraping

Viator's supplier portal is protected by **Cloudflare Bot Management**. Headless or simulated HTTP requests are fingerprinted and blocked.

However, when a real logged-in browser loads the reviews page, Viator injects all review data as a JSON blob inside a `<script>` tag using a server-side rendering (SSR) pattern:

```javascript
Object.assign(window, {"__PRELOADED_STATE__": { /* all reviews */ }});
```

By reading this in-memory object, we achieve three things simultaneously:

| Benefit | Explanation |
|---|---|
| **Bypass Cloudflare** | We are using a real authenticated browser session — indistinguishable from a human |
| **Bypass UI rendering limits** | The JSON contains ALL reviews for the page, not just what is visible in the viewport |
| **Avoid fragile CSS selectors** | We read structured, typed JSON — no HTML parsing needed |

### 3.2 The JSON Extraction Algorithm

The `__PRELOADED_STATE__` blob can be hundreds of kilobytes. We cannot simply `JSON.parse(document.body.innerText)`. Instead, the script uses a **depth-tracking brace parser** to extract only the relevant JSON object:

```javascript
// Step 1 — Find the right <script> tag
var scripts = document.scripts;
var text = null;
for (var s = 0; s < scripts.length; s++) {
    if (scripts[s].textContent.indexOf('__PRELOADED_STATE__') > -1) {
        text = scripts[s].textContent;
        break;
    }
}
if (!text) return 'ERROR: No script found';

// Step 2 — Find the start of the JSON after "Object.assign(window,"
var marker = 'Object.assign(window,';
var start = text.indexOf(marker) + marker.length;

// Step 3 — Walk character-by-character, track { brace depth }
// Exit when depth returns to 0 (closing brace of the outer object)
var depth = 0, inStr = false, esc = false, end = -1;
for (var i = start; i < text.length; i++) {
    var c = text[i];
    if (esc)               { esc = false; continue; }
    if (c==='\\' && inStr) { esc = true;  continue; }
    if (c==='"')           { inStr=!inStr; continue; }
    if (!inStr) {
        if (c==='{') depth++;
        else if (c==='}') { if (--depth===0) { end=i; break; } }
    }
}

// Step 4 — Parse only the extracted substring
var outer = JSON.parse(text.substring(start, end + 1));
var state = outer.__PRELOADED_STATE__;
```

This is safe, memory-efficient, and handles nested JSON correctly including strings that contain brace characters.

### 3.3 Two-Phase Extraction Strategy

Viator requires two different extraction methods because the `__PRELOADED_STATE__` is only available on the initial page load:

| Phase | Pages | Method | Why |
|---|---|---|---|
| **Phase 1** | Page 1 only | `__PRELOADED_STATE__` JSON parsing | Server pre-loads all data; most reliable |
| **Phase 2** | Pages 2+ | DOM scraping (`[class*="ReviewView__reviewView"]`) | The `__PRELOADED_STATE__` is replaced/absent after navigation; must fall back to DOM |

**Phase 2 DOM extraction details:**

| Field | Selector Used | Notes |
|---|---|---|
| Review ID | `data-automation` attribute → strip `"review-"` prefix | |
| Date | `[class*="ReviewHeader__reviewDate"]` → `new Date(text)` | Parsed from "Oct 8, 2025" format |
| Rating | Count `<circle>` elements in `[class*="ratingBubbles"]` | Each filled circle = 1 star |
| Content | `[class*="ReviewView__reviewContent"]` clone → strip `visibility:hidden` spans | Hidden spans are "Show all" truncation artifacts |
| Reviewer | `[class*="ReviewerAvatar__reviewerAvatarName"]` | |

### 3.4 TripAdvisor Review Detection

Viator serves cross-posted TripAdvisor reviews in the same feed. Detection differs by phase:

- **Phase 1 (`__PRELOADED_STATE__`):** `r.source === 'TRIPADVISOR'` → `agencia = 'TripAdvisor'`
- **Phase 2 (DOM):** Entity text starts with `"tripadvisor review:"` (case-insensitive) → strip prefix, set `source = 'TripAdvisor'`

The platform name written to Excel column B reflects this distinction.

### 3.5 Destino Fallback Logic

If no city keyword matches in the tour title, Viator applies a colon-extraction fallback:

```javascript
// Extract text before the first colon
// "Barcelona: Full Day Art Tour" → Destino = "Barcelona"
var colonIdx = title.indexOf(':');
if (colonIdx > -1) destino = title.substring(0, colonIdx).trim();
```

This is specific to Viator because its tour titles frequently follow the pattern `"City: Tour Name"`.

---

## 4️⃣ Klook Bot — Technical Deep Dive

**File:** `Klook-Power-Automate.txt`

### 4.1 Why `.ant-table-row` Instead of Generic Table Selectors

Klook's Merchant portal is built on **Ant Design**, a React UI component library. Ant Design renders its data table using **multiple nested `<table>` elements** for layout:

- A header "ghost" table (for sticky column headers)
- A body scroll table (for actual data rows)
- A footer table (sometimes present)

This means:

| Selector | Problem |
|---|---|
| `document.querySelectorAll('tr')` | Returns hundreds of rows — most are structural layout rows with no data |
| `document.querySelectorAll('table')` | Returns multiple tables — cannot reliably identify the correct one |
| `document.querySelectorAll('.ant-table-row')` | ✅ **Correct** — Ant Design assigns this class exclusively to actual data rows |

The `.ant-table-row` selector precisely targets only the rendered data rows, ignoring all ghost/layout elements.

### 4.2 🚨 Critical: `.item()` vs `[]` Array Syntax

This is the single most important implementation detail in the entire suite.

**The Problem:**

PAD's clipboard parser — used when pasting `.txt` flow code — interprets square brackets `[]` as part of its own variable and list-access syntax. As a result, JavaScript bracket notation like `rows[i]` or `cells[0]` gets **silently stripped or mangled** when PAD processes the pasted code. The flow imports without error, but the JavaScript is broken at runtime.

**The Solution — use DOM `.item()` method:**

```javascript
// ❌ WILL BREAK — PAD's clipboard parser strips the brackets
var row  = rows[i];
var cell = cells[0];

// ✅ CORRECT — .item() uses method-call syntax PAD does not touch
var row  = rows.item(i);
var cell = cells.item(0);
```

`.item()` is a standard DOM method on `NodeList` and `HTMLCollection` objects (the types returned by `querySelectorAll` and `getElementsByClassName`). It is **functionally identical** to bracket notation but uses method-call syntax that PAD's parser leaves intact.

> ⚠️ **Developer Rule:** Any time you add new JavaScript to the Klook flow (or any PAD flow) that accesses a `NodeList` or `HTMLCollection` by index, you **must** use `.item(index)` — never `[index]`.

### 4.3 Date Validation Guard

Before processing any row, the JS scraper validates the date cell format:

```javascript
var reviewDateStr = getCellText(4); // Column index 4 = review date

// Guard: skip rows where the date cell doesn't look like a real date
if (!reviewDateStr.match(/^\d{4}-\d{2}-\d{2}/)) {
    continue;
}
```

This prevents the date comparison logic from choking on header cells or empty rows that may appear in the DOM during Ant Design's virtual scroll re-renders.

### 4.4 Date Range Construction

Unlike GYG (which compares PAD `DateTime` objects), Klook compares **ISO date strings lexicographically** — this works because the `YYYY-MM-DD` format sorts identically to chronological order:

```
PAD actions build the date strings:
  DateTime → Text.ConvertDateTimeToText (SortableDateTime) → "2026-04-12T14:30:00"
  Text.GetSubtext (first 10 chars) → "2026-04-12"  (= StartDateString)

JavaScript comparison:
  if (reviewDateStr < StartDateString) { /* skip — older than cutoff */ }

PAD comparison:
  IF Review['review_time'] < StartDateString THEN EXIT LOOP
```

> ⚠️ **Critical:** Variable references in the `IF` comparison and `GetSubtext` actions must use `%` delimiters (e.g., `%StartDateString%`). If they are stored as literal text strings instead, the comparison becomes `"2026-04-12" < "StartDateStr"` — which is lexicographically `True` (because `'S' > '2'`) — and **all reviews are skipped**. See Section 8 for the full error explanation.

### 4.5 Chinese Character Mappings (Klook Japan)

Klook Japan sometimes returns tour titles in Traditional Chinese for cross-market listings. The bot includes explicit mappings for these:

| Traditional Chinese | Mapped Destino | Mapped Spanish Title |
|---|---|---|
| `威尼斯和維羅納` | `Venecia` | _(Destino detection only)_ |
| `從米蘭出發，乘坐火車前往威尼斯和維羅納一日遊` | `Venecia` | `Venecia y Verona desde Milán` |
| `托雷多與塞哥維亞` | `Toledo y Segovia` | _(Destino detection only)_ |
| `托雷多與塞哥維亞歷史名城之旅` | `Toledo y Segovia` | `Toledo y Segovia desde Madrid` |

### 4.6 Pagination

Klook uses Ant Design's pagination component. The bot clicks the next page button via JavaScript after each page is processed:

```javascript
function ExecuteScript() {
    var nextBtn = document.querySelector(
        'li[title="Next Page"], .ant-pagination-next, button[aria-label*="next" i]'
    );
    if (nextBtn
        && !nextBtn.className.includes('disabled')
        && !nextBtn.hasAttribute('disabled')) {
        nextBtn.click();
        return "CLICKED";
    }
    return "DONE";
}
```

When `"DONE"` is returned, the PAD loop exits. A `WAIT 6` seconds pause follows each click to allow the new page to fully render before the next scrape cycle.

### 4.7 Reviewer Anonymity

Klook's merchant portal does not expose reviewer usernames in the review table UI. All Klook reviews are written to column C as `"Anonymous"` — this is not a bug.

---

## 5️⃣ Civitatis Bot — Technical Deep Dive

**File:** `Civitatis-Power-Automate.txt`

### 5.1 Architecture: No Browser Required

Unlike the other three bots, Civitatis does **not** use a web browser. It reads entirely from a `.xls` file downloaded manually from the Civitatis supplier panel. This is the most reliable extraction method in the suite — there is no DOM to parse, no JavaScript to run, and no authentication to manage.

### 5.2 Why `StartRow = 5` — Skipping Header Rows

The Civitatis `listado.xls` report has a fixed structure:

| Row | Content |
|---|---|
| 1 | Report title / branding |
| 2 | Date range metadata |
| 3 | Blank spacer row |
| 4 | Column headers: `ID` · `Fecha` · `Producto` · `Nota` · `Comentario` |
| **5+** | **Actual review data** |

The PAD `Excel.ReadFromExcel.ReadCells` action uses `StartRow: 5`.

**Why this matters:** If `StartRow` were set to 1–4, PAD would attempt to convert the text `"Fecha"` (column header in row 4) into a `DateTime` object, because the date column is typed. This produces the hard error: **"Datetime must be Datetime"**. Starting at row 5 skips all headers entirely.

### 5.3 Blank Row and Invalid Data Guards

Even with `StartRow: 5`, reports may contain trailing blank rows or data anomalies. The flow uses three nested guards:

```
LOOP FOREACH Row IN CivitatiData

    SET CivDateRaw TO Row['Column2']   ← The date cell

    IF CivDateRaw <> '' THEN           ← Guard 1: Skip blank rows

        IF CivDateRaw <> 'Fecha' THEN  ← Guard 2: Skip residual header rows
                                           (redundant safety net)
            SET Nota TO Row['Column4']

            IF Nota >= 1 THEN          ← Guard 3: Skip zero/invalid ratings

                ... process and write to Excel ...

            END
        END
    END

END
```

### 5.4 Civitatis Rating Scale — Important Differences

Civitatis uses a **native 1–10 scale**, unlike the other platforms which use 1–5. This creates different calculations for all derived fields:

| Field | Formula | Example: Nota = 9 | Example: Nota = 7 |
|---|---|---|---|
| **Calificación** (col J) | `= Nota` (no conversion) | 9 | 7 |
| **RatingValue** (col K) | `= Nota / 2` | 4.5 | 3.5 |
| **NPS** | See thresholds below | Promotor | Pasivo |

**NPS thresholds — Civitatis vs other platforms:**

| Platform | Scale | Promotor | Pasivo | Detractor |
|---|---|---|---|---|
| GYG / Viator / Klook | 1–5 | Rating = **5** | Rating = **4** | Rating ≤ **3** |
| **Civitatis** | 1–10 | Nota ≥ **9** | Nota **7–8** | Nota ≤ **6** |

### 5.5 Date Filtering

Civitatis filters by date using string comparison (same as Klook):

```
ReviewDateShort >= StartDateString
```

Where both are `YYYY-MM-DD` strings. The `StartDateString` is computed from `CurrentDateTime - DaysBack` days, formatted with `Text.ConvertDateTimeToText (SortableDateTime)` and trimmed to 10 characters.

---

## 6️⃣ Core ETL Logic (Common to All Bots)

### 6.1 Destination (Destino) Mapping

All four bots contain identical Destino mapping logic. Tour title keywords are checked case-insensitively; the **first match wins**.

**Full mapping table:**

| Keyword(s) Searched In Tour Title | Destino Written | Sheet Region |
|---|---|---|
| `London` | `Londres` | EUR_NY |
| `Amsterdam` | `Ámsterdam` | EUR_NY |
| `Barcelona` | `Barcelona` | EUR_NY |
| `Madrid` | `Madrid` | EUR_NY |
| `Rome`, `Roma` | `Roma` | EUR_NY |
| `Paris` | `París` | EUR_NY |
| `Milan` | `Milán` | EUR_NY |
| `New York`, `NYC` | `Nueva York` | EUR_NY |
| `Granada` | `Granada` | EUR_NY |
| `Seville`, `Sevilla` | `Sevilla` | EUR_NY |
| `Florence`, `Firenze` | `Florencia` | EUR_NY |
| `Venice`, `Venezia` | `Venecia` | EUR_NY |
| `Toledo`, `Segovia` | `Toledo y Segovia` | EUR_NY |
| `Tokyo` | `Tokyo` | JAP |
| `Kyoto` | `Kyoto` | JAP |
| `Osaka` | `Osaka` | JAP |
| `Cancun`, `Cancún` | `Cancún` | LATAM |
| `Mexico City`, `Ciudad de Mexico`, `CDMX` | `Ciudad de México` | LATAM |

**Fallback behaviour when no keyword matches:**

| Bot | Fallback |
|---|---|
| GYG | `Destino` left empty (`''`) |
| Viator | `Destino` set to raw tour title; also tries colon-extraction (text before first `:`) |
| Klook | `Destino` set to raw `activity_name` |
| Civitatis | `Destino` set to raw `ProductName` |

### 6.2 Tour Title Standardisation

Applied in all four bots after Destino detection. These ensure cross-platform consistency in Excel reports:

| If Tour Title Contains | Replaced With |
|---|---|
| `Andorra, France & Spain` | `Andorra y Francia desde Barcelona` |
| `NYC Highlights Tour` | `Contrastes de NY` |
| `Statue of Liberty Tour with Ellis Island` | `Estatua de la Libertad (Guiado)` |
| `Two-Day Combo: Niagara Falls and Washington` | `Combo: Niagará & Washington DC en 2 días` |
| `Niagara Falls 1-Day Tour from NYC` | `Cataratas del Niágara` |
| `Washington DC & Philadelphia 1-Day` | `Washington DC y Filadelfia` |
| `London: Guided Tour Westminster Abbey` | `Westminster y Parlamento de Londres` |
| `Private Tour to Westminster Abbey` | `Westminster y Parlamento de Londres PRIVADO` |

Klook and Civitatis additionally include the Chinese-character equivalents (see Section 4.5).

### 6.3 NPS Calculation Logic

The NPS logic is identical across all bots, adjusted for the rating scale of each platform.

**GYG / Viator / Klook (1–5 scale):**
```
SET NPS TO 'Detractor'            ← default
IF RatingValue >= 5 THEN
    SET NPS TO 'Promotor'
END
IF RatingValue >= 4 THEN
    IF RatingValue < 5 THEN
        SET NPS TO 'Pasivo'       ← exactly 4
    END
END
```

**Civitatis (1–10 scale):**
```
SET NPS TO 'Detractor'            ← default
IF Nota >= 9 THEN
    SET NPS TO 'Promotor'
END
IF Nota >= 7 THEN
    IF Nota < 9 THEN
        SET NPS TO 'Pasivo'       ← 7 or 8
    END
END
```

> 📝 **Note on the nested `IF` pattern:** PAD does not have `ELSE IF`. The nested structure (`check ≥4` only after failing the `≥5` check) is necessary to correctly identify the Pasivo range (exactly 4) without re-entering the Promotor branch.

---

## 7️⃣ Modifying the Logic

### 7.1 Adding a New Destination (Destino)

You must update **all four bot flows independently** — each contains its own copy of the mapping block.

**Step-by-step:**

1. Open the flow in PAD editor.
2. Find the Destino mapping block. It begins with:
   ```
   SET Destino TO ''
   ```
   and is followed by a series of `IF Contains(TourTitle, ...)` blocks.

3. Add your new `IF` block immediately **before** the fallback check (`IF Destino = '' THEN`):
   ```
   IF Contains(TourTitle, 'NewKeyword', False) THEN
       SET Destino TO 'NuevaCiudad'
   END
   ```
   The third parameter `False` means case-insensitive matching.

4. **If the new destination is LATAM or JAP,** also update the SheetRegion routing block. In GYG, search for `IF Destino = 'Cancun'`. In Viator/Klook/Civitatis the routing is done via the Supplier selection dropdown — you may need to add a case. Example:
   ```
   IF Destino = 'NuevaCiudad' THEN
       SET SheetRegion TO 'LATAM'
   END
   ```

5. Repeat for all four bot flows.

6. Ensure the target Excel workbook has the sheet `{MONTH}_{REGION}` for the new region. If not, create it (see Section 7.3).

**Example — Adding Lisbon:**
```
IF Contains(TourTitle, 'Lisbon', False) OR Contains(TourTitle, 'Lisboa', False) THEN
    SET Destino TO 'Lisboa'
END
```
Region: `EUR_NY` — no SheetRegion change needed.

### 7.2 Adding a New Tour Title Standardisation

1. Open the flow in PAD editor.
2. Find the tour title standardisation block. It is labelled with the comment `# 2. STANDARDIZE TOUR TITLES`.
3. Add a new `IF Contains` block:
   ```
   IF Contains(TourTitle, 'Original English Fragment', False) THEN
       SET TourTitle TO 'Título Estándar en Español'
   END
   ```
4. Use a **unique and specific fragment** of the original title. Too short = false positives; too long = misses slight title variations.
5. The standardisation block runs **after** the Destino block. The `TourTitle` at this point has already been used for Destino detection, so overwriting it here only affects what is written to Excel column G.
6. Repeat for all four bots if the tour appears on multiple platforms.

### 7.3 Adding a New Month Sheet

When a new calendar month begins, a new sheet must exist in the workbook before the bots will run successfully:

1. Open `Viator_Reviews_2026.xlsm` in Excel.
2. Right-click an existing month sheet tab → **Move or Copy** → check **Create a copy** → click **OK**.
3. Rename the copy to the required format: e.g., `MAY_EUR_NY`, `MAY_LATAM`, `MAY_JAP`.
4. Select all data rows (row 2 downward) → **Delete** the rows, leaving only row 1 (headers).
5. Verify the TEXTJOIN formula in the Guía column is present in row 1 and references `GuidesList!A:A`.
6. Repeat for each region sheet needed.

---

## 8️⃣ Common Errors & Fixes

### Quick Reference Table

| Error | Bot(s) | Root Cause | Fix |
|---|---|---|---|
| `Unexpected character 'E'` parsing JSON | Viator, Klook | JS returned `"ERROR: No script found"` — page not loaded when OK clicked | Wait for full page load before clicking OK |
| 0 reviews extracted | Klook | (a) Variable passed as literal string; (b) `[]` brackets stripped from JS | Use `%VariableName%` syntax; use `.item()` notation |
| `Datetime must be Datetime` | Civitatis | Script tried to parse a header or blank row as DateTime | Confirm `StartRow: 5`; confirm blank/header guards are present |
| `Token not found` | GYG | OK clicked before triggering a filter to activate the API call | Restart; click a filter, wait for page reload, then click OK |
| PAD refuses to paste `.txt` | All | Clipboard contains invisible HTML formatting characters | Use the Notepad Cleanse (paste into Notepad first) |
| HTTP 401 / API Error | GYG | Bearer token expired mid-run | Restart flow; capture a fresh token |
| `Sheet not found` error | All | Target sheet (e.g., `MAY_EUR_NY`) doesn't exist in workbook | Create the missing sheet (see Section 7.3) |
| Destino column is wrong or empty | All | Tour title doesn't match any keyword in the mapping | Add a new Destino mapping (see Section 7.1) |

---

### Detailed Error Explanations

#### ❌ Error: `Unexpected character encountered while parsing value: E`

**Full PAD error:**
```
Variables.ConvertJsonToCustomObject: Unexpected character encountered while
parsing value: E. Path '', line 0, position 0.
```

**Root cause:** PAD received the plain string `"ERROR: No script found"` from JavaScript and attempted to parse it as JSON. The string's first character `E` is not valid JSON.

**Why it happens:** The user clicked OK on the login-complete dialog before the page had fully rendered. The JavaScript extractor ran, found no `__PRELOADED_STATE__` script tag (Viator) or no `.ant-table-row` elements (Klook), and returned an error string instead of a JSON array.

**Fix:**
1. Click **Stop** in PAD to halt the flow.
2. Close the Edge window PAD opened.
3. Restart the flow from the beginning.
4. At the login-complete prompt, **wait** until the review table or cards are fully visible on screen.
5. Click OK only after confirming data is loaded.

---

#### ❌ Error: 0 Reviews Extracted (Klook)

This error has two completely distinct root causes:

**Cause A — Variable passed as a literal string:**

After a bad `.txt` import, variable references may lose their `%` delimiters:

```
✅ Correct (PAD variable):      %StartDateString%
❌ After bad import (literal):  $'''StartDateStr'''
```

The `GetSubtext` action that builds `StartDateString` stores the result in a PAD variable. If the subsequent `IF` comparison action receives the **name** of the variable as a literal string rather than its **value**, the comparison becomes:

```
"2026-04-12" < "StartDateStr"   →  True (lexicographic: 'S' > '2')
```

Every single review is therefore treated as "before the cutoff" and skipped. The loop completes with 0 results and no error.

**Fix:** In PAD editor, open the `Get Subtext` actions and the `IF` comparison actions. Ensure variable names appear in the **variable field** with `%` signs, not as quoted string literals.

**Cause B — Square bracket notation stripped from JavaScript:**

If `rows[i]` or `cells[0]` bracket syntax was stripped by PAD's clipboard parser, the JavaScript throws a syntax or reference error at runtime and returns an empty result.

**Fix:** Search every `ExecuteJavascript` block for index access patterns (`[0]`, `[i]`, `[s]`, `[b]`, etc.) and replace with `.item(0)`, `.item(i)`, `.item(s)`, `.item(b)`.

---

#### ❌ Error: `Datetime must be Datetime` (Civitatis)

**Root cause:** PAD's `Text.ConvertDateTimeToText` action received a non-DateTime value — either the text `"Fecha"` (the column header from row 4) or an empty string from a blank trailing row.

**Why it happens:** Either `StartRow` was changed from `5`, or the `listado.xls` file structure has changed (e.g., extra header rows were added, or the file was manually edited before running).

**Fix:**
1. Open `listado.xls` in Excel. Confirm rows 1–4 are header content and row 5 is the first data row.
2. In PAD editor, confirm `StartRow: 5` in the `Excel.ReadFromExcel` action.
3. Confirm both guards are present and correctly placed:
   - `IF CivDateRaw <> ''` (blank row guard)
   - `IF CivDateRaw <> 'Fecha'` (header row guard)

---

#### ❌ Error: PAD Refuses to Paste `.txt` Code

**Symptom:** Paste appears to succeed but no actions appear in the workspace, OR PAD shows an immediate syntax error.

**Root cause:** The clipboard contains invisible HTML formatting characters — zero-width spaces, non-breaking spaces (`\u00A0`), Unicode control characters — introduced by copying from a browser, PDF viewer, or rich-text editor.

**Fix — The Notepad Cleanse:**

```
1. Open the .txt file
2. Press Ctrl+A  →  Ctrl+C
3. Open Windows Notepad (Start → Notepad — NOT Notepad++, NOT VS Code)
4. Press Ctrl+V  (paste into Notepad)
5. Press Ctrl+A  →  Ctrl+C  (copy from Notepad)
6. Switch to PAD editor → click workspace → Ctrl+V
```

Windows Notepad strips all formatting, leaving only plain UTF-8 text that PAD's parser handles correctly.

---

## 9️⃣ Guide Name Extraction — TEXTJOIN Formula

### 9.1 Formula

Place this formula in the **Guía** column of each output sheet:

```excel
=TEXTJOIN(", ", TRUE, FILTER(GuidesList!A:A, ISNUMBER(SEARCH(" " & GuidesList!A:A & " ", " " & [@Comentario] & " "))))
```

### 9.2 How It Works

| Component | Role |
|---|---|
| `GuidesList!A:A` | Full list of guide names — one per row |
| `" " & GuidesList!A:A & " "` | Pads each name with spaces — prevents `"Ana"` matching `"Anabel"` |
| `" " & [@Comentario] & " "` | Pads the comment text with spaces on both sides |
| `SEARCH(...)` | Case-insensitive position search — returns a number if found, an error if not |
| `ISNUMBER(...)` | Converts: found → `TRUE`, not found → `FALSE` |
| `FILTER(GuidesList!A:A, ...)` | Returns only the guide names where the match was `TRUE` |
| `TEXTJOIN(", ", TRUE, ...)` | Joins all matched names with `", "` separator; `TRUE` skips empty results |

**Why the space-padding works:**

Without padding, `SEARCH("Ana", "Carlos and Anabel")` would match `"Ana"` inside `"Anabel"`. With padding, `SEARCH(" Ana ", " Carlos and Anabel ")` does not match. The comment text is also padded so names at the very start or end of the comment are still found.

### 9.3 GuidesList Sheet Setup

The `GuidesList` sheet must exist in `Viator_Reviews_2026.xlsm`. Structure — one guide name per row in **Column A**, starting at row 1:

```
Row 1:  Carlos García
Row 2:  María López
Row 3:  Pedro Sánchez
Row 4:  Ana Rodríguez
...
```

**Rules:**
- Use the name exactly as it appears in customer reviews (check accent marks)
- For common first names, always use `"First Last"` to avoid false positives
- Do not include titles (Mr., Ms., Sr., Sra.)
- One entry per row — never combine multiple names in one cell

### 9.4 Maintaining the Guide List

| Action | How to Do It |
|---|---|
| **Add a guide** | Enter their name in the next empty row in `GuidesList!A`. Formula recalculates automatically. |
| **Remove a guide** | Right-click the row → **Delete Row** (do not just clear the cell — blank cells cause `FILTER` to return empty strings) |
| **Rename a guide** | Edit the cell directly. All historical matches recalculate on next workbook open. |

---

## 🔮 Adding a New Platform

If a future OTA platform needs to be added to the suite, follow this architectural checklist:

1. **Assess the extraction method.** Does the platform have a stable backend API? Hidden JSON state (like Viator)? A structured DOM table (like Klook)? Choose the **least fragile** approach: API > JSON state > DOM.

2. **Determine authentication.** Is a bearer token needed (use Requestly)? Cookie-based session (read via `document.cookie` in JS)? OAuth or 2FA (document the manual steps needed)?

3. **Identify the rating scale.** Is it 1–5 or 1–10? Update the `Calificación` formula and NPS thresholds accordingly in the new flow.

4. **Map the platform's data fields** to the standard Excel column schema (A–R). Identify which fields are not available (e.g., reviewer name) and default those to `"Anonymous"`.

5. **Build the JavaScript extractor.** Remember: ES5 only. No arrow functions, no `const`/`let`. Use `.item(index)` for all `NodeList` access.

6. **Copy the standard Destino and TourTitle blocks** from an existing bot. Add any platform-specific fallback logic (e.g., Viator's colon-extraction).

7. **Test the date range filter.** Use `DaysBack = 1` and verify the output matches what is visible in the portal UI for the same date range.

8. **Add a supplier selection dialog** if the platform has multiple accounts — follow the Viator/Klook `Display.SelectFromListDialog` pattern.

9. **Handle pagination.** Confirm the loop iterates through all pages, not just the first.

10. **Test with 0 results.** Run with a very small `DaysBack` on a quiet day and confirm the bot shows a "No reviews found" message gracefully rather than throwing an error.

---

## Appendix A — PAD Action Quick Reference

| PAD Action | Purpose | Key Parameters |
|---|---|---|
| `WebAutomation.LaunchEdge` | Open Edge browser | `Url`, `WindowState: Maximized` |
| `WebAutomation.ExecuteJavascript` | Run JavaScript in browser tab | `Javascript`, `Result=>` |
| `Variables.ConvertJsonToCustomObject` | Parse JSON string → PAD object | `Json`, `CustomObject=>` |
| `Variables.CreateNewList` | Initialise an empty list | `List=>` |
| `Variables.AddItemToList` | Append item to a list | `Item`, `List` |
| `Variables.IncreaseVariable` | Increment a counter | `Value`, `IncrementValue` |
| `Excel.LaunchExcel.LaunchAndOpenUnderExistingProcess` | Open workbook (reuse existing Excel instance) | `Path`, `Instance=>` |
| `Excel.SetActiveWorksheet.ActivateWorksheetByName` | Switch to a named sheet | `Name` |
| `Excel.InsertRow` | Insert a blank row above `Index` | `Index: 2` (always insert at row 2) |
| `Excel.WriteToExcel.WriteCell` | Write a value to a specific cell | `Column`, `Row`, `Value` |
| `Excel.GetFirstFreeRowOnColumn` | Find first empty row in a column | `Column: A`, `FirstFreeRowOnColumn=>` |
| `Excel.SaveExcel.Save` | Save the workbook | `Instance` |
| `Excel.CloseExcel.Close` | Close a workbook | `Instance` |
| `Display.ShowMessageDialog` | Show an informational dialog | `Title`, `Message`, `Buttons` |
| `Display.InputDialog` | Prompt user for free-text input | `UserInput=>` |
| `Display.SelectFromListDialog` | Dropdown selection dialog | `List`, `SelectedItem=>` |
| `DateTime.GetCurrentDateTime.Local` | Get current local date/time | `DateTimeFormat`, `CurrentDateTime=>` |
| `DateTime.Add` | Add or subtract time from a DateTime | `TimeToAdd: -%DaysBack%`, `TimeUnit: Days` |
| `Text.ConvertDateTimeToText` | Format DateTime as string | `StandardFormat: SortableDateTime` |
| `Text.GetSubtext` | Extract a substring by character position | `CharacterPosition: 0`, `NumberOfChars: 10` |
| `Text.ConvertTextToDateTime` | Parse a date string into DateTime | Used in GYG for `createdAt` field |
| `Web.InvokeWebService.InvokeWebServicePost` | Make HTTP POST (GYG GraphQL only) | `Url`, `CustomHeaders`, `RequestBody` |

---

## Appendix B — Variable Naming Conventions

| Variable | Example Value | Meaning |
|---|---|---|
| `DaysBack` | `4` | Lookback window in days |
| `CutoffDate` | DateTime object | Earliest date to include (GYG) |
| `StartDateString` | `"2026-03-15"` | ISO string of cutoff date (Klook/Civitatis) |
| `EndDateString` | `"2026-04-18"` | ISO string of today (Klook/Civitatis) |
| `MonthCode` / `MonthAbbrev` | `"ABR"` | Spanish month abbreviation |
| `SheetRegion` | `"EUR_NY"` | Regional sheet suffix |
| `TargetSheet` | `"ABR_EUR_NY"` | Full target sheet name |
| `ExcelInstance` | Instance reference | Handle to output workbook |
| `SourceExcel` | Instance reference | Handle to Civitatis `.xls` source file |
| `TotalWritten` | `42` | Count of reviews written in this run |
| `AllReviews` | List | Reviews accumulated before Excel write (Viator) |
| `ReviewsBatch` | Custom Object | Parsed JSON for the current page |
| `BatchHitCutoff` | `True` / `False` | Set when a review older than cutoff is found (GYG) |
| `AuthToken` | `"Bearer eyJ..."` | GYG bearer token including `"Bearer "` prefix |
| `SupplierId` | `"45999"` | GYG supplier ID read from cookie |
| `Offset` | `0`, `50`, `100`... | GYG GraphQL pagination offset |
| `PageNumber` | `1`, `2`, `3`... | Klook pagination counter |
| `AccountRegion` | `"UK"` | User-entered GYG account region (informational) |
| `SupplierChoice` | `"UK — Amigo Tours UK (18521)"` | Full dropdown selection string (Viator/Klook) |

---

*Document version 1.0 — April 2026 · AT Operations & Technology Team*
*For operator-facing run instructions, see [`README.md`](README.md)*
