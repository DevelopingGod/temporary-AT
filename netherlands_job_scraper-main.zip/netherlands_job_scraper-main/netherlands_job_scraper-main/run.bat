@echo off
echo Starting the Flask web scraper app...
python app.py
pause
