# scrapers/indeednl_scraper.py

from scrapers.base import BaseScraper
import undetected_chromedriver as uc
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
from bs4 import BeautifulSoup
from dotenv import load_dotenv
import urllib.parse
import os
import time
import logging
from colorlog import ColoredFormatter

# Load environment
load_dotenv()

# Setup logging
handler = logging.StreamHandler()
handler.setFormatter(ColoredFormatter(
    "%(log_color)s%(levelname)-8s:%(reset)s %(message)s",
    log_colors={
        "DEBUG": "cyan",
        "INFO": "green",
        "WARNING": "yellow",
        "ERROR": "red",
        "CRITICAL": "bold_red"
    },
))
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
logger.addHandler(handler)

CHROMEDRIVER_PATH = os.getenv("CHROMEDRIVER_PATH", r"C:\Users\a.ramkumar\Documents\chromedriver-win64\chromedriver-win64\chromedriver.exe")
BASE_URL_INDEED_NL = "https://nl.indeed.com"

class IndeedNLScraper(BaseScraper):
    def __init__(self):
        self.driver = None

    def setup_driver(self):
        options = uc.ChromeOptions()
        options.add_argument("--no-sandbox")
        options.add_argument("--disable-dev-shm-usage")
        options.add_argument("--window-size=1920,1080")
        options.add_argument("--disable-blink-features=AutomationControlled")
        options.add_argument("user-agent=Mozilla/5.0")
        self.driver = uc.Chrome(options=options)

    def scrape(self, job_role, region='', skills_str='', job_type=None, date_posted=None, radius=None):
        logger.info("Starting IndeedNLScraper.scrape()")
        vacancies = []
        seen_keys = set()
        self.setup_driver()

        query = job_role
        if skills_str:
            query += ' ' + skills_str

        base_params = {
            'q': query,
            'l': region,
            'jt': job_type,
            'fromage': date_posted,
            'radius': radius if radius else '25',
            'sc': '0bf:exrec();'
        }

        try:
            page = 1
            while True:
                start_index = (page - 1) * 10
                params = base_params.copy()
                if start_index > 0:
                    params['start'] = str(start_index)

                query_string = urllib.parse.urlencode({k: v for k, v in params.items() if v})
                url = f"{BASE_URL_INDEED_NL}/jobs?{query_string}"
                logger.info(f"Visiting Page {page}: {url}")
                self.driver.get(url)

                if "Just a moment..." in self.driver.title:
                    logger.warning("Page still loading... waiting extra 10 seconds")
                    time.sleep(10)
                else:
                    time.sleep(2)

                logger.debug(f"After get(): current_url = {self.driver.current_url}")
                logger.debug(f"Page title: {self.driver.title}")

                if page == 1:
                    try:
                        cookie_btn = WebDriverWait(self.driver, 5).until(
                            EC.element_to_be_clickable((By.ID, "onetrust-accept-btn-handler"))
                        )
                        logger.info("Accepting cookies")
                        cookie_btn.click()
                        time.sleep(1)
                    except TimeoutException:
                        logger.warning("Cookie consent button not found or already accepted.")
                    except Exception as e:
                        logger.error(f"Unexpected error while handling cookies: {type(e).__name__}: {e}")
                        return []

                soup = BeautifulSoup(self.driver.page_source, 'html.parser')
                job_cards = soup.find_all('div', class_='job_seen_beacon')

                if not job_cards:
                    logger.warning(f"No job cards found on page {page}. Ending loop.")
                    break

                new_jobs = 0
                for card in job_cards:
                    title_tag = card.find('h2', class_='jobTitle')
                    title_link = title_tag.find('a') if title_tag else None
                    title = title_link.get_text(strip=True) if title_link else "N/A"
                    link = BASE_URL_INDEED_NL + title_link['href'] if title_link and title_link.get('href') else "N/A"

                    company = (
                        card.find('span', class_='companyName') or
                        card.find('span', attrs={'data-testid': 'company-name'}) or
                        card.select_one('span[class*="company"]')
                    )
                    location = (
                        card.find('div', class_='companyLocation') or
                        card.find('div', attrs={'data-testid': 'text-location'}) or
                        card.select_one('div[class*="location"]')
                    )

                    key = (
                        title.strip().lower(),
                        (company.get_text(strip=True) if company else "").strip().lower(),
                        (location.get_text(strip=True) if location else "").strip().lower()
                    )

                    if key in seen_keys:
                        continue

                    seen_keys.add(key)
                    new_jobs += 1

                    vacancies.append({
                        'Job Title': title,
                        'Company': company.get_text(strip=True) if company else "N/A",
                        'Location': location.get_text(strip=True) if location else "N/A",
                        'Skills/Keywords': skills_str or job_role,
                        'Source': 'Indeed NL',
                        'Link': link,
                        'Description Snippet': "Visit link for details"
                    })

                    if not company:
                        logger.warning("Missing company name in job card.")
                        logger.debug(card.prettify())

                logger.info(f"Page {page}: Collected {new_jobs} new jobs.")

                if new_jobs == 0:
                    logger.info("All jobs on this page were duplicates. Ending pagination.")
                    break

                page += 1

        except Exception as e:
            logger.error(f"Error during scrape: {type(e).__name__}: {e}")
            import traceback
            traceback.print_exc()

        finally:
            if self.driver:
                self.driver.quit()
            logger.info(f"Finished scraping Indeed NL. Total jobs: {len(vacancies)}")

        return vacancies
