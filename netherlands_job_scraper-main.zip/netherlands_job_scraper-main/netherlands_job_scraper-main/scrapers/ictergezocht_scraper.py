# scrapers/ictergezocht_scraper.py

import undetected_chromedriver as uc
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

from scrapers.base import BaseScraper
import time
from urllib.parse import quote_plus
import logging
from colorlog import ColoredFormatter

# Setup logging
handler = logging.StreamHandler()
handler.setFormatter(ColoredFormatter(
    "%(log_color)s%(levelname)-8s:%(reset)s %(message)s",
    log_colors={
        "DEBUG": "cyan",
        "INFO": "green",
        "WARNING": "yellow",
        "ERROR": "red",
        "CRITICAL": "bold_red"
    },
))
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
logger.addHandler(handler)

class IcterGezochtScraper(BaseScraper):
    BASE_URL = "https://www.ictergezocht.nl/ict-vacatures/"

    def scrape(self, job_role, region, skills_str, radius="30", job_type=None, date_posted=None):
        logger.info("Entered IcterGezochtScraper.scrape()")
        logger.info(f"Params: job_role='{job_role}', region='{region}', skills='{skills_str}', job_type='{job_type}', date_posted='{date_posted}'")

        # Build search parameters
        query_params = {
            "filtered": "1",
            "what": job_role,
            "where": region,
            "r": radius,
            "salary": "",
            "comptype[]": "1"  # Only employers, excludes recruitment agencies
        }

        if skills_str:
            query_params["what"] += f", {skills_str}"

            
        if date_posted in ["1", "3", "7", "14"]:
            query_params["date"] = date_posted

        query_string = "&".join(f"{key}={quote_plus(value)}" for key, value in query_params.items())
        full_url = f"{self.BASE_URL}?{query_string}"

        logger.info(f"Navigating to: {full_url}")

        options = uc.ChromeOptions()
        options.add_argument("--disable-gpu")
        options.add_argument("--no-sandbox")
        options.add_argument("--window-size=1920,1080")

        driver = uc.Chrome(options=options)
        driver.get(full_url)

        try:
            previous_count = 0
            max_tries = 15
            tries = 0

            while tries < max_tries:
                driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
                time.sleep(2)

                try:
                    load_more = WebDriverWait(driver, 3).until(
                        EC.element_to_be_clickable((By.CSS_SELECTOR, ".load-more-btn, .load-more, button.load-more"))
                    )
                    logger.info("Clicking 'Load more' button...")
                    driver.execute_script("arguments[0].click();", load_more)
                    time.sleep(3)
                except:
                    logger.warning("No 'Load more' button (or not clickable yet).")

                job_cards = driver.find_elements(By.CSS_SELECTOR, "a.vacancy.vac")
                current_count = len(job_cards)
                if current_count == previous_count:
                    logger.info("No new jobs loaded. Ending scroll loop.")
                    break
                else:
                    previous_count = current_count
                    logger.info(f"Loaded {previous_count} jobs so far.")
                    tries += 1

            time.sleep(2)  # Final wait

            job_cards = driver.find_elements(By.CSS_SELECTOR, "a.vacancy.vac")
            logger.info(f"Found {len(job_cards)} job blocks")

            vacancies = []
            for card in job_cards:
                try:
                    title = card.find_element(By.TAG_NAME, "h3").text.strip()
                    link = card.get_attribute("href").strip()

                    location_company_div = card.find_element(By.CSS_SELECTOR, "div.location-and-company-name")
                    location = location_company_div.find_element(By.TAG_NAME, "strong").text.strip()
                    full_text = location_company_div.text.strip()
                    company = full_text.replace(location, "").replace("•", "").strip()

                    vacancies.append({
                        "Job Title": title,
                        "Company": company,
                        "Location": location,
                        "Skills/Keywords": skills_str,
                        "Source": "IcterGezocht",
                        "Link": link,
                        "Description Snippet": "N/A"
                    })
                except Exception as e:
                    logger.warning(f"Error parsing a job card: {e}")
                    continue

            return vacancies

        finally:
            driver.quit()
            logger.info("Finished IcterGezocht scraping.")
