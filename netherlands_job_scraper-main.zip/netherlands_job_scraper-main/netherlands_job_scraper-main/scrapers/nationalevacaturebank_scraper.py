import logging
from scrapers.base import BaseScraper
import undetected_chromedriver as uc
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
from bs4 import BeautifulSoup
from dotenv import load_dotenv
import os
import time
import urllib.parse
import colorlog

load_dotenv()

handler = colorlog.StreamHandler()
handler.setFormatter(colorlog.ColoredFormatter(
    "%(log_color)s[%(levelname)s] %(message)s",
    log_colors={
        'DEBUG':    'cyan',
        'INFO':     'green',
        'WARNING':  'yellow',
        'ERROR':    'red',
        'CRITICAL': 'bold_red',
    }
))
logger = colorlog.getLogger()
logger.addHandler(handler)
logger.setLevel(logging.INFO)

BASE_URL_NATIONALE = "https://www.nationalevacaturebank.nl"

class NationaleVacaturebankScraper(BaseScraper):
    def __init__(self):
        self.driver = None

    def setup_driver(self):
        options = uc.ChromeOptions()
        options.add_argument("--disable-gpu")
        options.add_argument("--no-sandbox")
        options.add_argument("--disable-dev-shm-usage")
        options.add_argument("--window-size=1920,1080")
        self.driver = uc.Chrome(options=options)

    def scrape(self, job_role, region='', skills_str='', job_type=None, date_posted=None, radius=None):
        logging.info("Starting NationaleVacaturebankScraper.scrape()")
        vacancies = []

        full_query = f"{job_role} {skills_str}".strip() if skills_str and skills_str.strip() else job_role
        params = {
            'query': full_query,
            'sort': 'relevance',
        }

        if job_type == "fulltime":
            params["filters[workingHours][min]"] = "33"
            params["filters[workingHours][max]"] = "40"
        elif job_type == "parttime":
            params["filters[workingHours][min]"] = "1"
            params["filters[workingHours][max]"] = "32"

        if date_posted in ["1", "3", "7", "14"]:
            params['filters[datePosted]'] = date_posted

        if region.strip():
            params['location'] = region.strip()
            params['distance'] = radius if radius else '20'

        else:
            logging.info("No region provided → searching nationwide")

        query_string = urllib.parse.urlencode(params)
        url = f"{BASE_URL_NATIONALE}/vacature/zoeken?{query_string}"

        self.setup_driver()
        logging.info(f"Visiting → {url}")
        self.driver.get(url)

        try:
            try:
                cookie_btn = WebDriverWait(self.driver, 10).until(
                    EC.element_to_be_clickable((By.XPATH, "//button[contains(translate(., 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), 'accepteer alle') or contains(translate(., 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), 'allow all')]"))
                )
                logging.info("Clicking cookie consent")
                cookie_btn.click()
                time.sleep(2)
            except TimeoutException:
                logging.warning("No cookie popup or already accepted.")
            except Exception as e:
                logging.warning(f"Error clicking cookie: {e}")

            scroll_pause = 2
            max_retries = 4
            retries = 0
            last_count = 0

            while True:
                self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
                time.sleep(scroll_pause)

                current_cards = self.driver.find_elements(By.XPATH, "//a[@data-analytics-action='ClickOnJob']")
                current_count = len(current_cards)
                logging.info(f"Scroll check: {current_count} jobs loaded...")

                if current_count == last_count:
                    retries += 1
                    if retries >= max_retries:
                        logging.info("No new jobs after multiple scrolls. Stopping.")
                        break
                else:
                    retries = 0
                    last_count = current_count

            WebDriverWait(self.driver, 20).until(
                EC.presence_of_all_elements_located((By.XPATH, "//a[@data-analytics-action='ClickOnJob']"))
            )
            logging.info("Job listings fully loaded")

            soup = BeautifulSoup(self.driver.page_source, 'html.parser')
            job_links = soup.find_all('a', attrs={'data-analytics-action': 'ClickOnJob'})
            logging.info(f"Found {len(job_links)} job cards")

            for job_item in job_links:
                title = company = location = link = "N/A"

                if job_item.get('href'):
                    href = job_item['href']
                    link = href if href.startswith("http") else BASE_URL_NATIONALE + href

                head_div = job_item.find('div', class_=lambda x: x and x.startswith('nvb_head__'))
                if head_div:
                    h2 = head_div.find('h2')
                    if h2:
                        title = h2.get_text(strip=True)

                details = job_item.find('div', class_=lambda x: x and x.startswith('nvb_companyDetails__'))
                if details:
                    comp = details.find('strong', class_=lambda x: x and x.startswith('nvb_companyName__'))
                    if comp:
                        company = comp.get_text(strip=True)

                    span_location = details.find('span')
                    if span_location:
                        location = span_location.get_text(strip=True)

                vacancies.append({
                    'Job Title': title,
                    'Company': company,
                    'Location': location,
                    'Skills/Keywords': skills_str or job_role,
                    'Source': 'Nationale Vacaturebank',
                    'Link': link,
                    'Description Snippet': "Details in link"
                })

        except Exception as e:
            logging.error(f"Error during scrape: {type(e).__name__}: {e}")
            import traceback
            traceback.print_exc()

        finally:
            if self.driver:
                self.driver.quit()
            logging.info(f"Finished scraping Nationale Vacaturebank. Total jobs: {len(vacancies)}")

        return vacancies
