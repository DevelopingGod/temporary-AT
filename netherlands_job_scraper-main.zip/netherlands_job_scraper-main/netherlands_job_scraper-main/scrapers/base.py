from abc import ABC, abstractmethod
from typing import List, Dict

class BaseScraper(ABC):
    @abstractmethod
    def scrape(self, job_role: str, region: str, skills_keywords: str = None) -> List[Dict[str, str]]:
        """
        Scrape job listings for a given job role, region, and optional skills/keywords.
        
        Returns:
            A list of dictionaries, each representing a job vacancy.
        """
        pass
