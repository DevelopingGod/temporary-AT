from scrapers.nationalevacaturebank_scraper import NationaleVacaturebankScraper
from scrapers.indeednl_scraper import IndeedNLScraper
from .ictergezocht_scraper import IcterGezochtScraper

SCRAPER_REGISTRY = {
     "nationale_vacaturebank": NationaleVacaturebankScraper,
     "indeed_nl": IndeedNLScraper,
     "ictergezocht": IcterGezochtScraper
}