from flask import Flask, render_template, request, send_file, flash
import csv
import io
import os
import json
from datetime import date

from scrapers.registry import SCRAPER_REGISTRY

app = Flask(__name__)
app.secret_key = 'your_very_secret_key_for_flask_flashing'

SEEN_JOBS_PATH = os.path.join(os.path.dirname(__file__), "seen_jobs.json")

def load_seen_jobs():
    """Load the persistent seen-jobs store from disk. Returns (seen_set, raw_list)."""
    try:
        if os.path.exists(SEEN_JOBS_PATH):
            with open(SEEN_JOBS_PATH, "r", encoding="utf-8") as f:
                raw_list = json.load(f)
            seen_set = {tuple(entry["key"]) for entry in raw_list}
            return seen_set, raw_list
    except Exception as e:
        print(f"⚠️ Could not load seen_jobs.json (treating as empty): {e}")
    return set(), []

def save_seen_jobs(raw_list):
    """Save the updated seen-jobs list back to disk."""
    try:
        with open(SEEN_JOBS_PATH, "w", encoding="utf-8") as f:
            json.dump(raw_list, f, ensure_ascii=False, indent=2)
    except Exception as e:
        print(f"⚠️ Could not save seen_jobs.json: {e}")

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/scrape', methods=['POST'])
def scrape_jobs_route():
    job_role = request.form.get('job_role')
    region = request.form.get('region', '').strip()
    skills_str = request.form.get('skills')
    portal = request.form.get('portal')
    job_type = request.form.get('job_type')
    date_posted = request.form.get('date_posted')
    radius = request.form.get('radius', '30')

    if not job_role:
        flash('Job Role is required!', 'error')
        return render_template('index.html', message='Job Role is required!', success=False)

    print(f"Received request: Role='{job_role}', Region='{region if region else 'N/A (Nationwide)'}', Skills='{skills_str}', Portal='{portal}'")
    print(f"👉 job_type: {job_type}, date_posted: {date_posted}")

    try:
        all_vacancies = []
        print("📡 Scraping ALL portals...")

        if portal == 'all':
            from scrapers.indeednl_scraper import IndeedNLScraper
            from scrapers.nationalevacaturebank_scraper import NationaleVacaturebankScraper
            from scrapers.ictergezocht_scraper import IcterGezochtScraper

            scrapers = [
                ("Indeed NL", IndeedNLScraper()),
                ("Nationale Vacaturebank", NationaleVacaturebankScraper()),
                ("IcterGezocht", IcterGezochtScraper())
            ]

            for name, scraper in scrapers:
                print(f"⚙️ Scraping using {name} ({scraper.__class__.__name__})")
                try:
                    result = scraper.scrape(job_role, region, skills_str, radius=radius, job_type=job_type, date_posted=date_posted)
                    all_vacancies.extend(result)
                except Exception as e:
                    print(f"❌ Error scraping {name}: {e}")
        else:
            print(f"🔎 Selected portal: {portal}")
            ScraperClass = SCRAPER_REGISTRY.get(portal)
            if ScraperClass is None:
                flash(f"Scraper for {portal} is not implemented yet.", 'error')
                return render_template('index.html', success=False)

            scraper = ScraperClass()
            all_vacancies = scraper.scrape(
                job_role, region, skills_str,
                radius=radius,  
                job_type=job_type, date_posted=date_posted
            )

        if not all_vacancies:
            print("No vacancies list returned from scraper or list is empty.")
            flash('No vacancies found with the given criteria or an error occurred during scraping.', 'info')
            return render_template('index.html', message='No vacancies found or error during scraping. Check console for details.', success=False)



        # Step 1: In-session deduplication (removes same-run cross-portal duplicates)
        seen_this_run = set()
        unique_vacancies = []
        duplicates = []

        for vac in all_vacancies:
            key = (
                vac.get("Job Title", "").strip().lower(),
                vac.get("Company", "").strip().lower(),
                vac.get("Location", "").strip().lower()
            )
            if key not in seen_this_run:
                seen_this_run.add(key)
                unique_vacancies.append(vac)
            else:
                duplicates.append(vac)

        print(f"🧹 In-session dedup: {len(unique_vacancies)} unique out of {len(all_vacancies)} scraped")

        # Step 2: Cross-run deduplication (filters jobs already seen in previous runs)
        persistent_seen, seen_jobs_raw = load_seen_jobs()
        previously_seen_vacancies = []
        new_vacancies = []

        for vac in unique_vacancies:
            key = (
                vac.get("Job Title", "").strip().lower(),
                vac.get("Company", "").strip().lower(),
                vac.get("Location", "").strip().lower()
            )
            if key in persistent_seen:
                previously_seen_vacancies.append(vac)
            else:
                new_vacancies.append(vac)

        print(f"📅 Cross-run dedup: {len(previously_seen_vacancies)} already seen in previous runs, {len(new_vacancies)} are new")

        # Recruiter filter
        RECRUITERS = {
            "randstad", "adecco", "manpower", "hays", "robert half", "michael page",
            "undutchables", "unique", "usg people", "rgf staffing", "luba",
            "adams multilingual", "blue lynx", "corecruitment", "atlas professionals",
            "starapple", "sterrk"
        }

        recruiters = []
        final_vacancies = []

        for vac in new_vacancies:
            company_name = vac.get("Company", "").lower()
            if any(recruiter in company_name for recruiter in RECRUITERS):
                recruiters.append(vac)
            else:
                final_vacancies.append(vac)

        print(f"🏢 Removed {len(recruiters)} recruiter listings. {len(final_vacancies)} remain.")

        # Step 3: Save ALL newly seen jobs (including recruiters) to the persistent store
        # so they are filtered out on future runs too
        today_str = date.today().isoformat()
        for vac in new_vacancies:
            key = [
                vac.get("Job Title", "").strip().lower(),
                vac.get("Company", "").strip().lower(),
                vac.get("Location", "").strip().lower()
            ]
            seen_jobs_raw.append({"key": key, "date_first_seen": today_str})
        save_seen_jobs(seen_jobs_raw)
        print(f"💾 Saved {len(new_vacancies)} new job keys to seen_jobs.json (total stored: {len(seen_jobs_raw)})")

        # If all results were already seen in previous runs, inform the user clearly
        if not final_vacancies:
            msg = (
                f'No NEW vacancies found. '
                f'{len(previously_seen_vacancies)} job(s) were filtered out as already seen in a previous run. '
                f'To reset history, delete seen_jobs.json from the project folder.'
            )
            print(f"ℹ️ {msg}")
            flash(msg, 'info')
            return render_template('index.html', message=msg, success=False)

        # Write output CSV to memory for download
        output = io.StringIO()
        fieldnames = list(final_vacancies[0].keys()) if final_vacancies else [
            'Job Title', 'Company', 'Location', 'Skills/Keywords', 'Source', 'Link', 'Description Snippet'
        ]
        writer = csv.DictWriter(output, fieldnames=fieldnames, extrasaction='ignore')
        writer.writeheader()
        writer.writerows(final_vacancies)
        output.seek(0)

        # Save recruiter-removed entries
        with open("filtered_out.csv", "w", newline='', encoding="utf-8") as f_recruiter:
            writer_dup = csv.DictWriter(f_recruiter, fieldnames=fieldnames)
            writer_dup.writeheader()
            writer_dup.writerows(recruiters)

        # Save duplicate-removed entries
        with open("removed_listings.csv", "w", newline='', encoding="utf-8") as f_dup:
            writer_dup = csv.DictWriter(f_dup, fieldnames=fieldnames)
            writer_dup.writeheader()
            writer_dup.writerows(duplicates)

        # Log previously-seen filter summary
        if previously_seen_vacancies:
            print(f"ℹ️ {len(previously_seen_vacancies)} job(s) hidden — already seen in a previous run.")

        # Return the final cleaned file to browser
        safe_job_role = "".join(c if c.isalnum() else "_" for c in job_role)
        safe_region = "".join(c if c.isalnum() else "_" for c in region) if region else "all_regions"
        filename = f"vacancies_{safe_job_role}_{safe_region}_{portal}.csv"

        return send_file(
            io.BytesIO(output.getvalue().encode('utf-8-sig')),
            mimetype='text/csv',
            as_attachment=True,
            download_name=filename
        )

    except Exception as e:
        import traceback
        print("\n🔴🔴🔴 EXCEPTION IN /scrape 🔴🔴🔴")
        traceback.print_exc()
        print("🔴🔴🔴 END OF TRACEBACK 🔴🔴🔴\n")

        flash(f'An unexpected error occurred: {str(e)}', 'error')
        return render_template('index.html', message=f'An error occurred: {str(e)}', success=False)

if __name__ == '__main__':
    app.run(debug=True, use_reloader=False)
