"""
Quick diagnostic: opens ictergezocht.nl, waits for content, dumps HTML and prints selector matches.
Run with: python debug_icter.py
"""
import undetected_chromedriver as uc
from selenium.webdriver.common.by import By
from webdriver_manager.chrome import ChromeDriverManager
import time

url = "https://www.ictergezocht.nl/ict-vacatures/?filtered=1&what=Software+Engineer&where=Amsterdam&r=30&salary=&comptype[]=1"

options = uc.ChromeOptions()
options.add_argument("--disable-gpu")
options.add_argument("--no-sandbox")
options.add_argument("--window-size=1920,1080")

driver = uc.Chrome(driver_executable_path=ChromeDriverManager().install(), options=options)
driver.get(url)

print("Waiting 5s for page to load...")
time.sleep(5)

driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
time.sleep(3)

# Dump HTML for inspection
with open("icter_dump.html", "w", encoding="utf-8") as f:
    f.write(driver.page_source)
print("Page source saved to icter_dump.html")

# Test known selectors
selectors = [
    "a.vacancy.vac",
    "a.vacancy",
    ".vacancy",
    "article",
    "[class*='vacancy']",
    "[class*='job']",
    "li.job",
    "div.job-card",
]

print("\n--- Selector matches ---")
for sel in selectors:
    elements = driver.find_elements(By.CSS_SELECTOR, sel)
    print(f"  {sel!r:35s} → {len(elements)} elements")

driver.quit()
print("\nDone. Open icter_dump.html in a browser to inspect the structure.")
