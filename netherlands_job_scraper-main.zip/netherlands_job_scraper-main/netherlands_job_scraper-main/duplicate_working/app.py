# app.py
from flask import Flask, render_template, request, send_file, flash
import csv
import io  # For sending file in memory
import os

from scrapers.registry import SCRAPER_REGISTRY  # Dynamic scraper lookup

app = Flask(__name__)
app.secret_key = 'your_very_secret_key_for_flask_flashing'  # Needed for flash messages

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/scrape', methods=['POST'])
def scrape_jobs_route():
    job_role = request.form.get('job_role')
    region = request.form.get('region', '').strip()
    skills_str = request.form.get('skills')
    portal = request.form.get('portal')
    job_type = request.form.get('job_type')
    date_posted = request.form.get('date_posted')
    radius = request.form.get('radius', '30')  



    if not job_role:
        flash('Job Role is required!', 'error')
        return render_template('index.html', message='Job Role is required!', success=False)

    print(f"Received request: Role='{job_role}', Region='{region if region else 'N/A (Nationwide)'}', Skills='{skills_str}', Portal='{portal}'")
    print(f"👉 job_type: {job_type}, date_posted: {date_posted}")

    try:
        all_vacancies = []
        print("📡 Scraping ALL portals...")

        if portal == 'all':
            from scrapers.indeednl_scraper import IndeedNLScraper
            from scrapers.nationalevacaturebank_scraper import NationaleVacaturebankScraper
            from scrapers.ictergezocht_scraper import IcterGezochtScraper

            scrapers = [
                ("Indeed NL", IndeedNLScraper()),
                ("Nationale Vacaturebank", NationaleVacaturebankScraper()),
                ("IcterGezocht", IcterGezochtScraper())
            ]


            for name, scraper in scrapers:
                print(f"⚙️ Scraping using {name} ({scraper.__class__.__name__})")

                try:
                    print(f"⚙️ Scraping using {name}...")
                    if name == "Indeed NL":
                        result = scraper.scrape(job_role, region, skills_str, job_type=job_type, date_posted=date_posted)
                    else:
                        result = scraper.scrape(job_role, region, skills_str, radius=radius)


                    all_vacancies.extend(result)
                except Exception as e:
                    print(f"❌ Error scraping {name}: {e}")
        else:
            print(f"🔎 Selected portal: {portal}")
            

            ScraperClass = SCRAPER_REGISTRY.get(portal)
            print(f"📦 Found scraper class: {ScraperClass}")
            if ScraperClass is None:
                flash(f"Scraper for {portal} is not implemented yet.", 'error')
                return render_template('index.html', success=False)
            
            scraper = ScraperClass()
            all_vacancies = scraper.scrape(
                job_role, region, skills_str,
                radius=radius,  
                job_type=job_type, date_posted=date_posted
            )

            
       

        if not all_vacancies:
            print("No vacancies list returned from scraper or list is empty.")
            flash('No vacancies found with the given criteria or an error occurred during scraping.', 'info')
            return render_template('index.html', message='No vacancies found or error during scraping. Check console for details.', success=False)

        output = io.StringIO()
        fieldnames = list(all_vacancies[0].keys()) if all_vacancies else [
            'Job Title', 'Company', 'Location', 'Skills/Keywords', 'Source', 'Link', 'Description Snippet'
        ]
    
        # 🧹 Deduplicate jobs based on Title + Company + Location + Link
        # 🧹 Deduplicate jobs based on Title + Company + Location + Link
        # 🧹 Improved deduplication (ignores tracking tokens in URLs)
        seen = set()
        unique_vacancies = []
        for vac in all_vacancies:
            key = (
                vac.get("Job Title", "").strip().lower(),
                vac.get("Company", "").strip().lower(),
                vac.get("Location", "").strip().lower()
            )
            if key not in seen:
                seen.add(key)
                unique_vacancies.append(vac)


        print(f"🧹 Removed duplicates: writing {len(unique_vacancies)} unique rows out of {len(all_vacancies)} total scraped")

        # 🚫 Recruiter filtering logic
        RECRUITERS = {
            "randstad", "adecco", "manpower", "hays", "robert half", "michael page",
            "undutchables", "unique", "usg people", "rgf staffing", "luba",
            "adams multilingual", "blue lynx", "corecruitment", "atlas professionals",
            "starapple", "sterrk"
        }

        recruiters = []
        final_vacancies = []

        for vac in unique_vacancies:
            company_name = vac.get("Company", "").lower()
            if any(recruiter in company_name for recruiter in RECRUITERS):
                recruiters.append(vac)
            else:
                final_vacancies.append(vac)

        print(f"🏢 Removed {len(recruiters)} recruiter listings. {len(final_vacancies)} remain.")

        # 🧾 Write final (cleaned) results to memory CSV
        output = io.StringIO()
        fieldnames = list(final_vacancies[0].keys()) if final_vacancies else [
            'Job Title', 'Company', 'Location', 'Skills/Keywords', 'Source', 'Link', 'Description Snippet'
        ]

        writer = csv.DictWriter(output, fieldnames=fieldnames, extrasaction='ignore')
        writer.writeheader()
        writer.writerows(final_vacancies)
        output.seek(0)

        # 💾 Save recruiter-filtered entries separately
        with open("filtered_out.csv", "w", newline='', encoding="utf-8") as f_dup:
            writer_dup = csv.DictWriter(f_dup, fieldnames=fieldnames)
            writer_dup.writeheader()
            writer_dup.writerows(recruiters)

        # 📎 Create safe filename
        safe_job_role = "".join(c if c.isalnum() else "_" for c in job_role)
        safe_region = "".join(c if c.isalnum() else "_" for c in region) if region else "all_regions"
        filename = f"vacancies_{safe_job_role}_{safe_region}_{portal}.csv"

        # 📤 Send the cleaned CSV to the user
        return send_file(
            io.BytesIO(output.getvalue().encode('utf-8')),
            mimetype='text/csv',
            as_attachment=True,
            download_name=filename
        )


    except Exception as e:
        import traceback
        print("\n🔴🔴🔴 EXCEPTION IN /scrape 🔴🔴🔴")
        traceback.print_exc()
        print("🔴🔴🔴 END OF TRACEBACK 🔴🔴🔴\n")

        flash(f'An unexpected error occurred: {str(e)}', 'error')
        return render_template('index.html', message=f'An error occurred: {str(e)}', success=False)

if __name__ == '__main__':
    app.run(debug=True, use_reloader=False)
