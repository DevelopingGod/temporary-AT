# scrapers/ictergezocht_scraper.py

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

from scrapers.base import BaseScraper
import time

class IcterGezochtScraper(BaseScraper):
    BASE_URL = "https://www.ictergezocht.nl/ict-vacatures/"

    def scrape(self, job_role, region, skills_str, radius="30", job_type=None, date_posted=None):
        # Build the full URL based on role and skills
        print("🚀 Entered IcterGezochtScraper.scrape()")
        print(f"🔍 Params received: job_role='{job_role}', region='{region}', skills='{skills_str}', job_type='{job_type}', date_posted='{date_posted}'")

        from urllib.parse import quote_plus

        # Build the full URL using the actual search format
        query_params = {
        "filtered": "1",
        "what": job_role,
        "where": region,
        "r": radius,
        "salary": "",
        "date": date_posted if date_posted else "",
        "comptype[]": "1"  # ✅ Only employers, excludes recruitment agencies
        }



        # Build skill keywords into 'what' parameter
        if skills_str:
            query_params["what"] += f", {skills_str}"

        # Encode query parameters
        query_string = "&".join(f"{key}={quote_plus(value)}" for key, value in query_params.items())
        full_url = f"{self.BASE_URL}?{query_string}"

        print(f"🔎 Navigating to: {full_url}")

        options = Options()
        # You can uncomment this for headless once everything works
        # options.add_argument("--headless=new")
        options.add_argument("--disable-gpu")
        options.add_argument("--no-sandbox")

        driver = webdriver.Chrome(options=options)
        driver.get(full_url)
        # Scroll to the bottom to trigger lazy-loading jobs
        last_height = driver.execute_script("return document.body.scrollHeight")

        for _ in range(5):  # Adjust this number as needed
            driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
            time.sleep(2)  # Wait for jobs to load
            new_height = driver.execute_script("return document.body.scrollHeight")
            if new_height == last_height:
                break  # No new content loaded
            last_height = new_height


        time.sleep(5)  # let JavaScript load content

        # Save page source for debugging
        with open("icter_dump.html", "w", encoding="utf-8") as f:
            f.write(driver.page_source)

        try:
            WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, "a.vacancy.vac"))
            )

            job_cards = driver.find_elements(By.CSS_SELECTOR, "a.vacancy.vac")


            print(f"✅ Found {len(job_cards)} job blocks")

            vacancies = []
            for card in job_cards:
                try:
                    title = card.find_element(By.TAG_NAME, "h3").text.strip()
                    link = card.get_attribute("href").strip()

                    location_company_div = card.find_element(By.CSS_SELECTOR, "div.location-and-company-name")
                    location = location_company_div.find_element(By.TAG_NAME, "strong").text.strip()
                    full_text = location_company_div.text.strip()
                    company = full_text.replace(location, "").replace("•", "").strip()

                    vacancies.append({
                        "Job Title": title,
                        "Company": company,
                        "Location": location,
                        "Skills/Keywords": skills_str,
                        "Source": "IcterGezocht",
                        "Link": link,
                        "Description Snippet": "N/A"
                    })
                except Exception as e:
                    print(f"⚠️ Error parsing a job card: {e}")
                    continue


            return vacancies

        finally:
            driver.quit()
