@echo off
echo Checking Python installation...
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo Python is not installed or not in PATH.
    echo Please install Python from https://www.python.org/downloads
    pause
    exit /b
)

echo Installing project dependencies...
pip install -r requirements.txt

echo.
echo ✅ Setup complete. You're ready to run the scraper.
pause
